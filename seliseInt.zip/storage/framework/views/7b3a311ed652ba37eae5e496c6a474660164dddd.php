

<?php $__env->startSection('content'); ?>
    <?php

    $user = Session::get('user');
    $time = $user['time'];
    $userID = $user['user']->id;
    ?>
    <input type="hidden" value="<?php echo e(date('H:i:s', strtotime($time . ' +5 minutes'))); ?>" id="timeConvert">
    <input type="hidden" value="<?php echo e($userID); ?>" id="userID">
    <div class="container mt-4">
        <table class="table">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Book</th>
                    <th scope="col">Author Name</th>
                    <th scope="col">Price</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $i = 1;
                ?>
                <?php $__currentLoopData = $allBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"> <?php echo e($i); ?></th>
                        <td><?php echo e($book->book); ?></td>
                        <td><?php echo e($book->author_name); ?></td>
                        <td><?php echo e($book->price); ?></td>
                    </tr>
                    <?php
                        $i++;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script>
        $(document).ready(function() {
            var time = $('#timeConvert').val();
            var uId = $('#userID').val();
            var currentTime = new Date($.now());
            var ret = currentTime.toString().split(" ");
            var actTime = ret[4];

            if( time = actTime){
                changeToken();
            }
            function changeToken() {
                $.ajax({
                    url: '<?php echo e(route("updateToken")); ?>',
                    method: 'post',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {
                        id: uId,
                    },
                }).then(function(result) {
                    var modiTime = new Date($.now());
                    var modiret = modiTime.toString().split(" ");
                    var modiactTime = ret[4];
                    $('#timeConvert').val(modiactTime);
                });
            }

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seliseInt\resources\views/home.blade.php ENDPATH**/ ?>